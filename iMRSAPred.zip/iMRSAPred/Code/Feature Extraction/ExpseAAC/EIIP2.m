%Hydrophilicity Values of 20 Amino Acid

%EIIP VALUES OF AMINO ACIDS 
A=-0.50;
C=-1.00;
D=3.00;
E=3.00;
F=22.50;
G=0.00;
H=20.50;
I=21.80;
K=3.00;
L=21.80;
M=21.30;
N=0.20;
P=0.00;
Q=0.20;
R=3.00;
S=0.30;
T=20.40;
V=21.50;
W=23.40;
Y=22.30;




