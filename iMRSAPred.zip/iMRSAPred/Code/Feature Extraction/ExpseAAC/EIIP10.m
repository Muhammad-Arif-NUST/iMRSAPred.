% D (Aspartic acid) 0.1263
% R (Arginine) 0.0959
% F (Phenylalanine) 0.0946
% T (Threonine) 0.0941
% C (Cysteine) 0.0829
% S (Serine) 0.0829
% M (Methionine) 0.0823
% Q (Glutamine) 0.0761
% W (Tryptophan) 0.0548
% Y (Tyrosine) 0.0516
% A (Alanine) 0.0373
% K (Lysine) 0.0371
% H (Histidine) 0.0242
% P (Proline) 0.0198
% E (Glutamic acid) 0.0058
% V (Valine) 0.0057
% G (Glycine) 0.0050
% N (Asparagine) 0.0036
% I (Isoleucine) 0.0000
% L (Leucine) 0.0000

%EIIP VALUES OF AMINO ACIDS 
A=-0.06;
C=1.36;
D=-0.80;
E=-0.77;
F=1.27;
G=-0.41;
H=0.49;
I=1.31;
K=-1.18;
L=1.21;
M=1.27;
N=-0.48;
P=0.00;
Q=-0.73;
R=-0.84;
S=-0.50;
T=-0.27;
V=1.09;
W=0.88;
Y=0.33;




