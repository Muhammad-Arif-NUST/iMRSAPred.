function [Calculate_Frequency]= Amino_Acid_Simple_Frequency(x)

% % ACD EFG HIK L MNP QRS TVW Y


index=find('A'==x);
j1 = size(index,2);

index=find('C'==x);
j2 = size(index,2);

index=find('D'==x);
j3 = size(index,2);

index=find('E'==x);
j4 = size(index,2);

index=find('F'==x);
j5 = size(index,2);

index=find('G'==x);
j6 = size(index,2);

index=find('H'==x);
j7 = size(index,2);

index=find('I'==x);
j8 = size(index,2);

index=find('K'==x);
j9 = size(index,2);

index=find('L'==x);
j10 = size(index,2);

index=find('M'==x);
j11 = size(index,2);

index=find('N'==x);
j12 = size(index,2);

index=find('P'==x);
j13 = size(index,2);

index=find('Q'==x);
j14 = size(index,2);

index=find('R'==x);
j15 = size(index,2);

index=find('S'==x);
j16 = size(index,2);

index=find('T'==x);
j17 = size(index,2);

index=find('V'==x);
j18 = size(index,2);

index=find('W'==x);
j19 = size(index,2);

index=find('Y'==x);
j20 = size(index,2);

Calculate_Frequency =[j1 j2 j3 j4 j5 j6 j7 j8 j9 j10 j11 j12 j13 j14 j15 j16 j17 j18 j19 j20];

end

