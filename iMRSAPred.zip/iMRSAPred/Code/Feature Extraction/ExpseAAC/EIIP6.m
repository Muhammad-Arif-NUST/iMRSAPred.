% D (Aspartic acid) 0.1263
% R (Arginine) 0.0959
% F (Phenylalanine) 0.0946
% T (Threonine) 0.0941
% C (Cysteine) 0.0829
% S (Serine) 0.0829
% M (Methionine) 0.0823
% Q (Glutamine) 0.0761
% W (Tryptophan) 0.0548
% Y (Tyrosine) 0.0516
% A (Alanine) 0.0373
% K (Lysine) 0.0371
% H (Histidine) 0.0242
% P (Proline) 0.0198
% E (Glutamic acid) 0.0058
% V (Valine) 0.0057
% G (Glycine) 0.0050
% N (Asparagine) 0.0036
% I (Isoleucine) 0.0000
% L (Leucine) 0.0000

%EIIP VALUES OF AMINO ACIDS 
A=6.11;
C=5.02;
D=2.98;
E=3.08;
F=5.91;
G=6.06;
H=7.64;
I=6.04;
K=9.47;
L=6.04;
M=5.74;
N=10.76;
P=6.30;
Q=5.65;
R=10.76;
S=5.68;
T=5.60;
V=6.02;
W=5.88;
Y=5.63;




