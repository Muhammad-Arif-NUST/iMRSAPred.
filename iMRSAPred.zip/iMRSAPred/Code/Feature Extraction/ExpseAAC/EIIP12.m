% Flexibility Values of 20 Amino Acid

%EIIP VALUES OF  AMINO ACIDS 
A=-3.102;
C=0.957;
D=0.424;
E=2.009;
F=-0.466;
G=-2.746;
H=-0.223;
I=0.424;
K=3.950;
L=0.424;
M=2.484;
N=0.424;
P=-2.404;
Q=2.009;
R=3.060;
S=0.957;
T=-1.339;
V=-1.339;
W=-1.000;
Y=-0.672;




