% D (Aspartic acid) 0.1263
% R (Arginine) 0.0959
% F (Phenylalanine) 0.0946
% T (Threonine) 0.0941
% C (Cysteine) 0.0829
% S (Serine) 0.0829
% M (Methionine) 0.0823
% Q (Glutamine) 0.0761
% W (Tryptophan) 0.0548
% Y (Tyrosine) 0.0516
% A (Alanine) 0.0373
% K (Lysine) 0.0371
% H (Histidine) 0.0242
% P (Proline) 0.0198
% E (Glutamic acid) 0.0058
% V (Valine) 0.0057
% G (Glycine) 0.0050
% N (Asparagine) 0.0036
% I (Isoleucine) 0.0000
% L (Leucine) 0.0000

%EIIP VALUES OF AMINO ACIDS 
A=91.50;
C=117.7;
D=124.5;
E=155.1;
F=203.4;
G=66.40;
H=167.3;
I=168.8;
K=171.3;
L=167.9;
M=170.8;
N=135.2;
P=129.3;
Q=161.1;
R=202.0;
S=99.10;
T=122.1;
V=141.7;
W=237.6;
Y=203.6;




