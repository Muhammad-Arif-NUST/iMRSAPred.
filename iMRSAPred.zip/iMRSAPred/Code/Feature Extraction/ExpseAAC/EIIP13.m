% Irreplaceability Values of 20 Amino Acid

%EIIP VALUES OF AMINO ACIDS 
A=0.52;
C=1.12;
D=0.77;
E=0.76;
F=0.86;
G=0.56;
H=0.94;
I=0.65;
K=0.81;
L=0.58;
M=1.25;
N=0.79;
P=0.61;
Q=0.86;
R=0.60;
S=0.64;
T=0.56;
V=0.54;
W=1.82;
Y=0.98;




