import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy.io as sio
import lightgbm as lgb
from catboost import CatBoostClassifier 
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.preprocessing import scale, StandardScaler
from sklearn.model_selection import cross_val_predict
from sklearn.model_selection import GridSearchCV
from sklearn import svm
#from sklearn.externals import joblib
import pickle
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import StratifiedKFold
import utils.tools as utils


from imblearn.combine import SMOTETomek

sepscores = []
ytest = np.ones((1, 2)) * 0.5
yscore = np.ones((1, 2)) * 0.5
#parameters = {'kernel': ['rbf'], 'C':map(lambda x:2**x,np.linspace(-2,5,7)), 'gamma':map(lambda x:2**x,np.linspace(-5,2,7))}
#parameters = {'kernel': ['rbf'], 'C':[2**-15: 2**15],'gamma':[0.001, 0.0001]}
#parameters = {'kernel': ['rbf'], 'C':[1, 10, 100, 1000], 'gamma':[0.001, 0.0001]}
#clf = GridSearchCV(svm.SVC(), parameters, cv=5, n_jobs=12, scoring='accuracy')
#C_range = 2. ** np.arange(-15, 15)
#gamma_range = 2. ** np.arange(-15, -5)
#param_grid = dict(gamma=gamma_range, C=C_range)
#clf = GridSearchCV(SVC(), param_grid=param_grid, cv=10)
#clf.fit(X,Y)
#C=clf.best_params_['C']
#gamma=clf.best_params_['gamma']
#parameter = {'depth'         : [4,5,6,7,8,9, 10],
                 '#learning_rate' : [0.01,0.02,0.03,0.04],
                  '#iterations'    : [10, 20,30,40,50,60,70,80,90, 100]
                 




def dumpmodel(X, y):
     Cboost = CatBoostClassifier(verbose=0, n_estimators=200)
    #yy = utils.to_categorical(y)
     Cboost.fit(X, y)
    #joblib.dump(svc, 'model\saved_model_PELM_RF.pkl')
     pickle.dump(Cboost, open('model\ACP-CatBoostModel.pkl', 'wb'))
     print("Saved model to disk")

def indepTesting(Xtest, Ytest):
     Sepscores = []
     ytest = np.ones((1, 2)) * 0.5
     yscore = np.ones((1, 2)) * 0.5
     # xtest=np.asarray(pd.read_csv(Xtest).iloc[:].values)
     # ytest=np.asarray(pd.read_csv(Xtest).iloc[:].values.ravel())
     xtest = np.vstack(Xtest)
     y_test = np.vstack(Ytest)
     ldmodel = pickle.load(open("model\ACP-CatBoostModel.pkl", 'rb'))
     print("Loaded model from disk")
     y_score = ldmodel.predict_proba(xtest)
     yscore = np.vstack((yscore, y_score))
     y_class = utils.categorical_probas_to_classes(y_score)

     fpr, tpr, _ = roc_curve(y_test, y_score[:, 1])
     roc_auc = auc(fpr, tpr)
     acc, precision, npv, sensitivity, specificity, mcc, f1 = utils.calculate_performace(len(y_class), y_class,
                                                                                         y_test)
     Sepscores.append([acc, precision,npv,sensitivity, specificity, mcc,f1,roc_auc])
     print('CatBoost:acc=%f,precision=%f,npv=%f,sensitivity=%f,specificity=%f,mcc=%f,f1=%f,roc_auc=%f'
           % (acc, precision, npv, sensitivity, specificity, mcc, f1, roc_auc))
     fpr, tpr, _ = roc_curve(y_test[:, 0], y_score[:, 1])
     auc_score = auc(fpr, tpr)
     scores = np.array(Sepscores)
     result1 = np.mean(scores, axis=0)
     H1 = result1.tolist()
     Sepscores.append(H1)
     result = Sepscores
     row = y_score.shape[0]
     yscore = y_score[np.array(range(1, row)), :]
     yscore_sum = pd.DataFrame(data=yscore)
     yscore_sum.to_csv('ind\ACP_test_Main_CatBoost_yscore.csv')
     y_test = y_test[np.array(range(1, row)), :]
     ytest_sum = pd.DataFrame(data=y_test)
     ytest_sum.to_csv('ind\ACP_test_Main_CatBoost_ytest.csv')
     colum = ['ACC', 'precision', 'npv', 'Sn', 'Sp', 'MCC', 'F1', 'AUC']
     # ro = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11']
     data_csv = pd.DataFrame(columns=colum, data=result)  # , index=ro)
     data_csv.to_csv('ind\ACP_test_Main_CatBoost_results.csv')
     lw = 2
     plt.plot(fpr, tpr, color='blue',
              lw=lw, label='SVC ROC (area = %0.2f%%)' % auc_score)
     plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
     plt.xlim([0.0, 1.05])
     plt.ylim([0.0, 1.05])
     plt.xlabel('False Positive Rate')
     plt.ylabel('True Positive Rate')
     plt.title('Receiver operating characteristic')
     plt.legend(loc="lower right")
     plt.grid()
     plt.show()
     plt.savefig('IndepRoc_ACP.png', dpi=300)

if __name__ == '__main__':
     ###data for training#######
     #data_train = sio.loadmat('SCMRSA_RECM_comp_TR.mat')
     #data = data_train.get('SCMRSA_RECM_comp_TR')  # Remove the data in the dictionary
     #label1 = np.ones((118 , 1))  # Value can be changed
     #label2 = np.zeros((678, 1))
     #label = np.append(label1, label2)
     #X = data
     #y = label

     #smotemok= SMOTETomek()
     #X_res, y_res = smotemok.fit_resample(X,y)


     #X = X_res
     #y = y_res


###############################2nd Loadiing method###
     ############data for testing#############
     data_test = sio.loadmat('SCMRSA_RECM_comp_TS.mat')
     data_test = data_test.get('SCMRSA_RECM_comp_TS')  # Remove the data in the dictionary
     label1_test = np.ones((30, 1))  # Value can be changed
     label2_test = np.zeros((169, 1))
     label_test = np.append(label1_test, label2_test)
     indepXtest = data_test
     indepYtest = label_test



     #########function calling###########
     
     dumpmodel(X, y)
     indepTesting(indepXtest, indepYtest)

